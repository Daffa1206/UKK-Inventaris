<?php
$koneksi = new mysqli("localhost", "root", "", "inventaris_barang");

// Ambil data kategori untuk dropdown
$kategoriResult = $koneksi->query("SELECT * FROM kategori");

// Ambil parameter pencarian, filter dan halaman
$search = isset($_GET['search']) ? $_GET['search'] : '';
$filter_kategori = isset($_GET['filter_kategori']) ? $_GET['filter_kategori'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 5; // Jumlah data per halaman
$offset = ($page - 1) * $limit;

// Query dasar
$baseQuery = "
    FROM barang 
    JOIN kategori ON barang.kategori_id = kategori.id
    WHERE 1
";

// Tambahkan kondisi pencarian
if (!empty($search)) {
    $baseQuery .= " AND (barang.nama_barang LIKE '%$search%' OR kategori.nama_kategori LIKE '%$search%')";
}

// Tambahkan filter kategori
if (!empty($filter_kategori)) {
    $baseQuery .= " AND kategori.id = '$filter_kategori'";
}

// Hitung total data
$countResult = $koneksi->query("SELECT COUNT(*) as total $baseQuery");
$totalData = $countResult->fetch_assoc()['total'];
$totalPages = ceil($totalData / $limit);

// Ambil data barang untuk halaman ini
$query = "SELECT barang.*, kategori.nama_kategori $baseQuery LIMIT $limit OFFSET $offset";
$barang = $koneksi->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory Barang</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-900 to-slate-800 text-white min-h-screen">

<!-- Navbar -->
<nav class="bg-slate-800 text-white px-4 py-3 shadow-md">
    <div class="max-w-6xl mx-auto flex justify-between items-center">
        <a href="index.php" h1 class="text-lg font-bold">Inventory Barang</h1>
        <div class="flex gap-2">
            <a href="tambah.php" class="bg-green-600 hover:bg-green-700 text-white text-sm font-medium px-3 py-1 rounded-md">+Barang</a>
            <a href="kategori.php" class="bg-green-600 hover:bg-green-700 text-white text-sm font-medium px-3 py-1 rounded-md">+Kategori</a>
            <a href="export_pdf.php" class="bg-red-600 hover:bg-red-700 text-white text-sm font-medium px-3 py-1 rounded-md">Export PDF</a>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="p-6 max-w-6xl mx-auto">
    <h1 class="text-3xl font-bold mb-6 text-center">📦 Daftar Barang Inventaris</h1>

    <!-- Pencarian dan Filter -->
    <form method="GET" class="mb-6 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-4xl mx-auto">
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Cari barang atau kategori..."
               class="w-full px-4 py-2 rounded-md text-black border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500">
        <select name="filter_kategori" class="w-full px-4 py-2 rounded-md text-black border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">Semua Kategori</option>
            <?php while ($row = $kategoriResult->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>" <?= $filter_kategori == $row['id'] ? 'selected' : '' ?>><?= $row['nama_kategori'] ?></option>
            <?php endwhile; ?>
        </select>
        <div class="flex gap-2">
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-sm">Cari</button>
            <a href="index.php" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 text-sm">Reset</a>
        </div>
    </form>

    <!-- Tabel -->
    <div class="overflow-x-auto rounded-lg shadow-lg">
        <table class="w-full text-sm text-left text-white">
            <thead class="bg-slate-700 uppercase text-xs text-gray-300">
                <tr>
                    <th class="px-6 py-3">NO</th>
                    <th class="px-6 py-3">Nama Barang</th>
                    <th class="px-6 py-3">Kategori</th>
                    <th class="px-6 py-3">Stok</th>
                    <th class="px-6 py-3">Harga</th>
                    <th class="px-6 py-3">Tanggal Masuk</th>
                    <th class="px-6 py-3">Aksi</th>
                </tr>
            </thead>
            <tbody class="bg-slate-800 divide-y divide-slate-700">
                <?php $no = $offset + 1; while ($data = $barang->fetch_assoc()): ?>
                <tr class="hover:bg-slate-700">
                    <td class="px-6 py-3"><?= $no++ ?></td>
                    <td class="px-6 py-3"><?= $data['nama_barang'] ?></td>
                    <td class="px-6 py-3"><?= $data['nama_kategori'] ?></td>
                    <td class="px-6 py-3"><?= $data['jumlah_stok'] ?></td>
                    <td class="px-6 py-3">Rp <?= number_format($data['harga_barang'], 0, ',', '.') ?></td>
                    <td class="px-6 py-3"><?= date("d-m-Y", strtotime($data['tanggal_masuk'])) ?></td>
                    <td class="px-6 py-3 flex gap-2">
                        <a href="edit.php?id=<?= $data['id'] ?>" class="bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-white text-xs">Edit</a>
                        <a href="hapus.php?id=<?= $data['id'] ?>" onclick="return confirm('Yakin ingin hapus?')" class="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-white text-xs">Hapus</a>
                    </td>
                </tr>
                <?php endwhile ?>
            </tbody>
        </table>
    </div>

    <!-- Navigasi Halaman -->
    <div class="mt-6 text-center">
        <?php if ($totalPages > 1): ?>
            <div class="inline-flex items-center gap-1">
                <?php if ($page > 1): ?>
                    <a href="?search=<?= $search ?>&filter_kategori=<?= $filter_kategori ?>&page=<?= $page - 1 ?>" class="px-3 py-1 bg-slate-700 hover:bg-slate-600 rounded">« Prev</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="?search=<?= $search ?>&filter_kategori=<?= $filter_kategori ?>&page=<?= $i ?>"
                       class="px-3 py-1 <?= $page == $i ? 'bg-blue-600 text-white' : 'bg-slate-700 hover:bg-slate-600' ?> rounded">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>

                <?php if ($page < $totalPages): ?>
                    <a href="?search=<?= $search ?>&filter_kategori=<?= $filter_kategori ?>&page=<?= $page + 1 ?>" class="px-3 py-1 bg-slate-700 hover:bg-slate-600 rounded">Next »</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
