<?php
$koneksi = new mysqli("localhost", "root", "", "inventaris_barang");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama_kategori = $_POST['nama_kategori'];
    $koneksi->query("INSERT INTO kategori (nama_kategori) VALUES ('$nama_kategori')");
    header("Location: kategori.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tambah Kategori</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white">

    <!-- Navbar -->
    <nav class="bg-gray-800 px-6 py-4 flex justify-between items-center">
        <h1 class="text-xl font-bold">Tambah Kategori</h1>
        <a href="kategori.php" class="bg-green-600 hover:bg-green-700 px-3 py-1 rounded">Kembali ke Daftar</a>
    </nav>

    <div class="flex justify-center mt-10">
        <form action="" method="POST" class="bg-gray-800 p-6 rounded-lg shadow-lg w-full max-w-md">
            <label>Nama Kategori</label>
            <input type="text" name="nama_kategori" class="w-full mb-3 p-2 rounded text-black" required>

            <button type="submit" class="bg-blue-600 hover:bg-blue-700 w-full py-2 rounded">Simpan</button>
        </form>
    </div>

</body>
</html>
