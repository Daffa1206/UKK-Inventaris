<?php
$koneksi = new mysqli("localhost", "root", "", "inventaris_barang");
$kategori = $koneksi->query("SELECT * FROM kategori");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daftar Kategori</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white">

    <!-- Navbar -->
    <nav class="bg-gray-800 px-6 py-4 flex justify-between items-center">
        <h1 class="text-xl font-bold">Daftar Kategori</h1>
        <div class="flex gap-4">
            <a href="tambah_kategori.php" class="bg-green-600 hover:bg-green-700 px-3 py-1 rounded">+ Kategori</a>
            <a href="index.php" class="bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded">Kembali</a>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <table align="center" class="w-[90%] md:w-[70%] text-left border-collapse">
            <thead class="bg-gray-700">
                <tr>
                    <th class="p-3">NO</th>
                    <th class="p-3">NAMA KATEGORI</th>
                    <th class="p-3">AKSI</th>
                </tr>
            </thead>
            <tbody class="bg-gray-800">
                <?php $no = 1; while($row = $kategori->fetch_assoc()): ?>
                <tr class="border-t border-gray-700">
                    <td class="p-3"><?= $no++ ?></td>
                    <td class="p-3"><?= $row['nama_kategori'] ?></td>
                    <td class="p-3">
                        <a href="edit_kategori.php?id=<?= $row['id'] ?>" class="bg-blue-500 hover:bg-blue-600 px-2 py-1 rounded">Edit</a>
                        <a href="hapus_kategori.php?id=<?= $row['id'] ?>" class="bg-red-600 hover:bg-red-700 px-2 py-1 rounded" onclick="return confirm('Yakin hapus kategori ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endwhile ?>
            </tbody>
        </table>
    </div>

</body>
</html>
