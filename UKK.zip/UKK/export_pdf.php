<?php
require 'dompdf/autoload.inc.php'; // Sesuaikan dengan lokasi dompdf

use Dompdf\Dompdf;

include 'koneksi.php';

// Ambil data dari database
$query = $koneksi->query("
    SELECT barang.*, kategori.nama_kategori 
    FROM barang 
    JOIN kategori ON barang.kategori_id = kategori.id
");

// Buat HTML untuk isi PDF
$html = '<h2 style="text-align:center;">Daftar Barang Inventaris</h2>';
$html .= '
<table border="1" cellpadding="6" cellspacing="0" width="100%">
    <thead style="background-color:#eee;">
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Kategori</th>
            <th>Stok</th>
            <th>Harga</th>
            <th>Tanggal Masuk</th>
        </tr>
    </thead>
    <tbody>';
$no = 1;
while ($data = $query->fetch_assoc()) {
    $html .= '<tr>
        <td>' . $no++ . '</td>
        <td>' . $data['nama_barang'] . '</td>
        <td>' . $data['nama_kategori'] . '</td>
        <td>' . $data['jumlah_stok'] . '</td>
        <td>Rp ' . number_format($data['harga_barang'], 0, ',', '.') . '</td>
        <td>' . date('d-m-Y', strtotime($data['tanggal_masuk'])) . '</td>
    </tr>';
}
$html .= '</tbody></table>';

// Inisialisasi Dompdf
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape'); // Bisa portrait juga
$dompdf->render();

// Output PDF ke browser
$dompdf->stream("data_barang.pdf", ["Attachment" => false]);
exit;
