<?php
include 'koneksi.php';
$id = $_GET['id'];

$data = $koneksi->query("SELECT * FROM barang WHERE id = $id")->fetch_assoc();
$kategori_query = $koneksi->query("SELECT * FROM kategori");

$updated = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $kategori = $_POST['kategori'];
    $stok = $_POST['stok'];
    $harga = $_POST['harga'];
    $tanggal_masuk = $_POST['tanggal_masuk'];

    $query = $koneksi->prepare("UPDATE barang SET nama_barang=?, kategori_id=?, jumlah_stok=?, harga_barang=?, tanggal_masuk=? WHERE id=?");
    $query->bind_param('siidsi', $nama, $kategori, $stok, $harga, $tanggal_masuk, $id);
    $query->execute();

    $updated = true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Barang</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://unpkg.com/@tabler/icons/iconfont/tabler-icons.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-800 to-slate-900 text-white min-h-screen p-4">

    <!-- Navbar -->
    <nav class="bg-slate-700 rounded-xl shadow-md p-4 flex justify-between items-center mb-10">
        <h1 class="text-2xl font-bold tracking-wide flex items-center gap-2">
            <i class="ti ti-package"></i> Edit Barang
        </h1>
        <a href="index.php" class="bg-emerald-600 hover:bg-emerald-700 px-4 py-2 rounded text-sm font-medium transition-all">
            <i class="ti ti-arrow-back-up"></i> Kembali
        </a>
    </nav>

    <div class="max-w-lg mx-auto bg-slate-800 p-6 rounded-2xl shadow-lg shadow-slate-700/50">
        <h2 class="text-xl font-semibold text-center mb-6">Update Data Barang</h2>
        <form method="POST" class="space-y-4 animate-fade-in">

            <div>
                <label class="block mb-1 text-sm font-medium">Nama Barang</label>
                <input name="nama" value="<?= $data['nama_barang'] ?>" required class="w-full p-3 rounded-md bg-slate-700 text-white placeholder:text-gray-400 focus:outline-none focus:ring focus:ring-blue-500" />
            </div>

            <div>
                <label class="block mb-1 text-sm font-medium">Kategori</label>
                <select name="kategori" required class="w-full p-3 rounded-md bg-slate-700 text-white focus:outline-none">
                    <option value="" disabled>Pilih Kategori</option>
                    <?php while ($kategori = $kategori_query->fetch_assoc()) : ?>
                        <option value="<?= $kategori['id'] ?>" <?= $kategori['id'] == $data['kategori_id'] ? 'selected' : '' ?>>
                            <?= $kategori['nama_kategori'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div>
                <label class="block mb-1 text-sm font-medium">Jumlah Stok</label>
                <input name="stok" type="number" value="<?= $data['jumlah_stok'] ?>" required class="w-full p-3 rounded-md bg-slate-700 text-white focus:outline-none" />
            </div>

            <div>
                <label class="block mb-1 text-sm font-medium">Harga Barang</label>
                <input name="harga" type="number" value="<?= $data['harga_barang'] ?>" required class="w-full p-3 rounded-md bg-slate-700 text-white focus:outline-none" />
            </div>

            <div>
                <label class="block mb-1 text-sm font-medium">Tanggal Masuk</label>
                <input name="tanggal_masuk" type="date" value="<?= $data['tanggal_masuk'] ?>" required class="w-full p-3 rounded-md bg-slate-700 text-white focus:outline-none" />
            </div>

            <div class="flex justify-end">
                <button class="bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded-lg text-sm font-medium transition-all">
                    <i class="ti ti-device-floppy"></i> Update
                </button>
            </div>
        </form>
    </div>

    <?php if ($updated): ?>
    <script>
        Swal.fire({
            title: 'Berhasil!',
            text: 'Data barang berhasil diperbarui.',
            icon: 'success',
            confirmButtonColor: '#2563eb'
        }).then(() => {
            window.location.href = "index.php";
        });
    </script>
    <?php endif; ?>

</body>
</html>
