<?php
$koneksi = new mysqli("localhost", "root", "", "inventaris_barang");
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}
?>
