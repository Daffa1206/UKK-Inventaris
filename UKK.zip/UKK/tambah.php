<?php
$koneksi = new mysqli("localhost", "root", "", "inventaris_barang");

$error = "";
$success = "";

// Mengambil data kategori dari database
$kategori = $koneksi->query("SELECT * FROM kategori");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama = trim($_POST['nama']);
    $kategori_id = $_POST['kategori'];
    $stok = $_POST['stok'];
    $harga = $_POST['harga'];
    $tanggal = $_POST['tanggal_masuk'];

    // Validasi input
    if (empty($nama) || empty($kategori_id) || empty($stok) || empty($harga) || empty($tanggal)) {
        $error = "Data tidak boleh kurang dari 1";
    } elseif ($stok <= 0 || $harga <= 10) {
        $error = "Stok dan Harga harus lebih dari 0!";
    } else {
        // Gunakan prepared statement untuk keamanan
        $stmt = $koneksi->prepare("INSERT INTO barang (nama_barang, kategori_id, jumlah_stok, harga_barang, tanggal_masuk) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("siiis", $nama, $kategori_id, $stok, $harga, $tanggal);

        if ($stmt->execute()) {
            $success = "Data berhasil ditambahkan!";
        } else {
            $error = "Gagal menyimpan data!";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-900 text-white min-h-screen pt-10 p-1">

    <!-- Navbar -->
    <nav class="fixed top-0 w-full z-50 bg-slate-800 text-white px-4 py-3 shadow-md">
        <div class="max-w-6xl mx-auto flex justify-between items-center">
            <h1 class="text-lg font-bold">Tambah Barang</h1>
            <a href="index.php" class="bg-green-600 hover:bg-green-700 text-white text-sm font-medium px-3 py-1 rounded-md">
                Kembali
            </a>
        </div>
    </nav>

    <?php if ($error): ?>
    <div class="max-w-md mx-auto mt-4 bg-red-600 text-white p-3 rounded shadow"><?= $error ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="max-w-md mx-auto mt-4 bg-green-600 text-white p-3 rounded shadow"><?= $success ?></div>
    <script>
        setTimeout(() => {
            window.location.href = 'index.php';
        }, 1500); // redirect setelah 1,5 detik
    </script>
<?php endif; ?>


    <!-- Form -->
    <div class="flex items-center justify-center min-h-[calc(100vh-80px)]">
        <div class="bg-slate-800 p-6 rounded-xl w-full max-w-md shadow-lg">
            <h2 class="text-xl font-bold mb-4 text-center">Tambah Barang</h2>
            <form action="" method="POST" class="space-y-3">
                
                <!-- Input untuk nama barang -->
                <input name="nama" type="text" class="w-full p-2 text-sm rounded bg-slate-700" placeholder="Nama Barang" required>

                <!-- Dropdown untuk kategori -->
                <select name="kategori" class="w-full p-2 text-sm rounded bg-slate-700" required>
                    <option value="" disabled>Pilih Kategori</option>
                    <?php while ($row = $kategori->fetch_assoc()): ?>
                        <option value="<?= $row['id'] ?>"><?= $row['nama_kategori'] ?></option>
                    <?php endwhile; ?>
                </select>

                <!-- Input untuk stok -->
                <input name="stok" type="number" class="w-full p-2 text-sm rounded bg-slate-700" placeholder="Jumlah Stok" required>

                <!-- Input untuk harga barang -->
                <input name="harga" type="number" class="w-full p-2 text-sm rounded bg-slate-700" placeholder="Harga Barang" required>

                <!-- Input untuk tanggal masuk barang -->
                <input name="tanggal_masuk" type="date" class="w-full p-2 text-sm rounded bg-slate-700" required>

                <!-- Tombol untuk menyimpan -->
                <div class="flex justify-end">
                    <button type="submit" class="bg-blue-600 px-4 py-1 text-sm rounded hover:bg-blue-700">Simpan</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>
