<?php
include 'koneksi.php';

// Ambil parameter pencarian dan filter kategori
$search = isset($_GET['search']) ? $_GET['search'] : '';
$filter_kategori = isset($_GET['filter_kategori']) ? $_GET['filter_kategori'] : '';

// Set header untuk output CSV
header("Content-type: text/csv");
header("Content-Disposition: attachment; filename=data_barang.csv");
header("Pragma: no-cache");
header("Expires: 0");

$output = fopen("php://output", "w");

// Header kolom CSV
fputcsv($output, ['ID', 'Nama Barang', 'Kategori', 'Stok', 'Harga', 'Tanggal Masuk']);

// Query dasar untuk export
$baseQuery = "
    SELECT barang.*, kategori.nama_kategori
    FROM barang 
    JOIN kategori ON barang.kategori_id = kategori.id
    WHERE 1
";

// Tambahkan kondisi pencarian
if (!empty($search)) {
    $baseQuery .= " AND (barang.nama_barang LIKE '%$search%' OR kategori.nama_kategori LIKE '%$search%')";
}

// Tambahkan filter kategori
if (!empty($filter_kategori)) {
    $baseQuery .= " AND kategori.id = '$filter_kategori'";
}

// Eksekusi query untuk export data
$query = $koneksi->query($baseQuery);

// Cek jika query tidak menghasilkan data
if ($query->num_rows > 0) {
    // Menulis data ke file CSV
    while ($row = $query->fetch_assoc()) {
        fputcsv($output, [
            $row['id'],
            $row['nama_barang'],
            $row['nama_kategori'],
            $row['jumlah_stok'],
            $row['harga_barang'],
            $row['tanggal_masuk']
        ]);
    }
} else {
    // Jika tidak ada data, berikan informasi
    fputcsv($output, ['Tidak ada data yang ditemukan']);
}

fclose($output);
exit;
?>
