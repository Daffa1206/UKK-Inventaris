<?php
$koneksi = new mysqli("localhost", "root", "", "inventaris_barang");
$id = $_GET['id'];
$koneksi->query("DELETE FROM kategori WHERE id = $id");
header("Location: kategori.php");
?>
